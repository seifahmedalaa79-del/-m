function performSearch() {
    const query = document.getElementById('search').value.toLowerCase();
    const content = document.querySelector('body');
    const paragraphs = content.getElementsByTagName('p');

  
    for (let paragraph of paragraphs) {
        paragraph.innerHTML = paragraph.textContent;
    }

    if (query) {
        for (let paragraph of paragraphs) {
            const text = paragraph.textContent;
            const regex = new RegExp(`(${query})`, 'gi');
            const highlightedText = text.replace(regex, '<span class="highlight">$1</span>');
            paragraph.innerHTML = highlightedText;
        }
    }
}